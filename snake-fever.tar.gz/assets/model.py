"""Deterministic grid rules, independent of pygame and rendering."""
from collections import deque
import random

SIZE = 20
DIRECTIONS = {'UP': (0, -1), 'DOWN': (0, 1), 'LEFT': (-1, 0), 'RIGHT': (1, 0)}
OPPOSITE = {'UP': 'DOWN', 'DOWN': 'UP', 'LEFT': 'RIGHT', 'RIGHT': 'LEFT'}


class Game:
    def __init__(self, seed=None):
        self.rng = random.Random(seed)
        self.reset()

    def reset(self):
        self.body = [(8, 10), (7, 10), (6, 10), (5, 10)]
        self.previous = self.body.copy()
        self.direction = 'RIGHT'
        self.previous_direction = self.direction
        self.queue = deque(maxlen=2)
        self.turn_target = None
        self.score = 0
        self.apples = 0
        self.status = 'ready'
        self.fever_left = 0.0
        self.fever_used = False
        self.hitstop = 0.0
        self.progress = 0.0
        self.events = []
        self.food = self.spawn_food()

    @property
    def fever(self):
        return self.fever_left > 0

    @property
    def speed(self):
        normal = min(16.0, 10 + self.apples * 0.12)
        return normal + (24 - normal) * min(1, self.fever_left / 2) if self.fever else normal

    def spawn_food(self):
        occupied = set(self.body)
        empty = [(x, y) for y in range(SIZE) for x in range(SIZE) if (x, y) not in occupied]
        return self.rng.choice(empty) if empty else None

    def turn(self, direction, assist=False):
        if direction not in DIRECTIONS or self.status not in ('ready', 'playing'):
            return
        previous = self.queue[-1] if self.queue else self.direction
        self.turn_target = None
        if direction not in (previous, OPPOSITE[previous]) and len(self.queue) < 2:
            if assist and not self.queue and self.food:
                dx, dy = DIRECTIONS[self.direction]
                tx, ty = DIRECTIONS[direction]
                x, y = self.body[0]
                fx, fy = self.food
                if dx and fx == x + dx and ty * (fy - y) > 0:
                    self.turn_target = (0, fx, direction)
                elif dy and fy == y + dy and tx * (fx - x) > 0:
                    self.turn_target = (1, fy, direction)
                if self.turn_target:
                    self.status = 'playing'
                    return
            self.queue.append(direction)
        if self.status == 'ready':
            self.status = 'playing'

    def activate_fever(self):
        if self.status != 'playing' or self.fever_used:
            return False
        self.fever_used = True
        self.fever_left = 10.0
        self.hitstop = 0.15
        self.events.append(('fever', self.body[0]))
        return True

    def update(self, dt):
        if self.status != 'playing':
            return
        # Small slices keep timer boundaries and movement consistent across frame rates.
        remaining = max(0.0, dt)
        while remaining > 1e-9 and self.status == 'playing':
            step_time = min(remaining, 1 / 240)
            remaining -= step_time
            if self.hitstop > 0:
                blocked = min(step_time, self.hitstop)
                self.hitstop -= blocked
                step_time -= blocked
            if step_time <= 0:
                continue
            self.progress += step_time * self.speed
            while self.progress >= 1 and self.status == 'playing':
                self.progress -= 1
                self.step()
            if self.fever_left > 0:
                old = self.fever_left
                self.fever_left = max(0, self.fever_left - step_time)
                if old > 2 >= self.fever_left:
                    self.events.append(('warning', self.body[0]))
                if self.fever_left == 0:
                    self.events.append(('fever_end', self.body[0]))

    def step(self):
        self.previous_direction = self.direction
        if self.turn_target and self.body[0][self.turn_target[0]] == self.turn_target[1]:
            self.direction = self.turn_target[2]
            self.turn_target = None
        elif self.queue:
            self.direction = self.queue.popleft()
        dx, dy = DIRECTIONS[self.direction]
        x, y = self.body[0]
        next_pos = (x + dx, y + dy)
        if self.fever:
            next_pos = (next_pos[0] % SIZE, next_pos[1] % SIZE)
        elif not (0 <= next_pos[0] < SIZE and 0 <= next_pos[1] < SIZE):
            self.die()
            return
        eating = next_pos == self.food
        occupied = self.body if eating else self.body[:-1]
        self.previous = self.body.copy()
        if next_pos in occupied:
            if not self.fever:
                self.die()
                return
            index = self.body.index(next_pos)
            self.body = self.body[:index]
            self.events.append(('trim', next_pos))
        elif not eating:
            self.body.pop()
        self.body.insert(0, next_pos)
        if self.direction != self.previous_direction:
            self.events.append(('turn', next_pos))
        if eating:
            self.apples += 1
            self.score += 2 if self.fever else 1
            self.events.append(('eat', next_pos))
            self.food = self.spawn_food()
            if self.food is None:
                self.status = 'won'
                self.events.append(('win', next_pos))

    def die(self):
        self.status = 'over'
        self.progress = 1.0
        self.events.append(('die', self.body[0]))

    def drain_events(self):
        events, self.events = self.events, []
        return events
