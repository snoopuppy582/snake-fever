# /// script
# dependencies = ["pygame-ce"]
# ///
"""Browser entry point; desktop gameplay and rendering stay unchanged."""
import asyncio
import json
import time

import pygame
import platform

from desktop_app import App, DEFAULTS

STORAGE_KEY = 'snake-fever.save.v1'


class WebApp(App):
    def load(self):
        try:
            data = json.loads(platform.window.localStorage.getItem(STORAGE_KEY) or '{}')
            self.best = max(0, int(data.get('best', 0)))
            saved = data.get('settings', {})
            for key in ('music', 'effects'):
                self.settings[key] = max(0, min(1, float(saved.get(key, DEFAULTS[key]))))
            for key in ('reduced_motion', 'assist'):
                self.settings[key] = bool(saved.get(key, DEFAULTS[key]))
        except Exception:
            # Storage may be disabled in private browsing or by site permissions.
            pass

    def save(self):
        try:
            platform.window.localStorage.setItem(
                STORAGE_KEY, json.dumps({'best': self.best, 'settings': self.settings}))
        except Exception:
            pass

    def handle(self, event):
        # F11 belongs to the browser, not SDL's desktop fullscreen mode.
        if event.type == pygame.KEYDOWN and event.key == pygame.K_F11:
            return
        super().handle(event)

    async def run_web(self):
        last = time.perf_counter()
        saved_best = self.best
        was_hidden = False
        platform.window.snakeFeverReady = True
        while self.running:
            now = time.perf_counter()
            dt, last = now - last, now
            hidden = bool(platform.window.document.hidden)
            for event in pygame.event.get():
                self.handle(event)
            if not self.running:
                break
            if hidden and not was_hidden:
                if self.game.status == 'playing':
                    self.pause()
                self.audio.pause(True)
                self.save()
            elif was_hidden and not hidden:
                self.audio.pause(self.game.status == 'paused' or bool(self.panel))
            was_hidden = hidden
            if dt > .25 and self.game.status == 'playing':
                self.pause()
            if not hidden:
                self.update(min(dt, .25))
                if self.best != saved_best:
                    self.save()
                    saved_best = self.best
                self.draw()
                self.clock.tick()
                self.fps = self.clock.get_fps()
            # Yield to browser input, audio, rendering, and requestAnimationFrame.
            await asyncio.sleep(0)
        self.save()
        pygame.quit()


async def main():
    app = WebApp()
    await app.run_web()


asyncio.run(main())
