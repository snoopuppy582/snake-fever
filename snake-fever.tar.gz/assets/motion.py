"""Continuous display geometry; the collision board stays an integer grid."""
import math
from functools import lru_cache


def edge_delta(a, b, size=20):
    return tuple((q - p + size / 2) % size - size / 2 for p, q in zip(a, b))


@lru_cache(maxsize=16)
def spine(previous, count, cell):
    cells = previous[:count]
    if not cells:
        return ()
    x, y = cells[0]
    points = [((x + .5) * cell, (y + .5) * cell)]
    for a, b in zip(cells, cells[1:]):
        dx, dy = edge_delta(a, b)
        points.append((points[-1][0] + dx * cell, points[-1][1] + dy * cell))
    result = points[:1]
    for a, b, c in zip(points, points[1:], points[2:]):
        if abs((b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0])) > .001:
            result.append(b)
    if len(points) > 1:
        result.append(points[-1])
    return tuple(result)


def body_path(body, previous, alpha, cell=32):
    alpha = max(0, min(1, alpha))
    dx, dy = edge_delta(previous[0], body[0])
    points = [((previous[0][0] + dx * alpha + .5) * cell,
               (previous[0][1] + dy * alpha + .5) * cell)]
    if len(body) > 1:
        # Keep the last bend until the moving tail has actually passed it.
        middle = spine(tuple(previous), len(body) - 1, cell)
        points.extend(middle)
        anchor = previous[min(len(body) - 2, len(previous) - 1)]
        tail = previous[min(len(body) - 1, len(previous) - 1)]
        ax, ay = edge_delta(anchor, tail)
        dx, dy = edge_delta(tail, body[-1])
        points.append((middle[-1][0] + (ax + dx * alpha) * cell,
                       middle[-1][1] + (ay + dy * alpha) * cell))
    pixels = []
    for point in points:
        if not pixels or math.dist(point, pixels[-1]) > .001:
            pixels.append(point)
    rounded = round_corners(pixels, cell * .34)
    result = rounded[:1]
    for a, b in zip(rounded, rounded[1:]):
        steps = max(1, math.ceil(math.dist(a, b) / 128))
        result.extend(tuple(a[i] + (b[i] - a[i]) * step / steps for i in (0, 1)) for step in range(1, steps + 1))
    return result


def round_corners(points, radius):
    if len(points) < 3:
        return points
    result = [points[0]]
    for a, b, c in zip(points, points[1:], points[2:]):
        length_in, length_out = math.dist(a, b), math.dist(b, c)
        incoming = ((b[0] - a[0]) / length_in, (b[1] - a[1]) / length_in)
        outgoing = ((c[0] - b[0]) / length_out, (c[1] - b[1]) / length_out)
        if abs(incoming[0] * outgoing[1] - incoming[1] * outgoing[0]) < .01:
            continue
        extent = min(radius, length_in * .45, length_out * .45)
        start = (b[0] - incoming[0] * extent, b[1] - incoming[1] * extent)
        end = (b[0] + outgoing[0] * extent, b[1] + outgoing[1] * extent)
        result.append(start)
        for step in range(1, 7):
            t = step / 6
            result.append(tuple((1 - t) ** 2 * start[i] + 2 * t * (1 - t) * b[i] + t * t * end[i] for i in (0, 1)))
    result.append(points[-1])
    return result


def tapered_path(points):
    if not points:
        return []
    distance = 0.0
    result = [(*points[-1], .7)]
    for a, b in zip(reversed(points), reversed(points[:-1])):
        length = math.dist(a, b)
        if distance < 42 < distance + length:
            t = (42 - distance) / length
            result.append((a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, 7))
        distance += length
        result.append((*b, .7 + 6.3 * min(1, distance / 42)))
    return result[::-1]


def wrapped_chunks(path, board=640):
    if not path:
        return []
    points = [(x % board, y % board, r) for x, y, r in path]
    chunks = [[points[0]]]
    for a, b in zip(points, points[1:]):
        sx = board if b[0] - a[0] < -board / 2 else -board if b[0] - a[0] > board / 2 else 0
        sy = board if b[1] - a[1] < -board / 2 else -board if b[1] - a[1] > board / 2 else 0
        if sx or sy:
            chunks[-1].append((b[0] + sx, b[1] + sy, b[2]))
            chunks.append([(a[0] - sx, a[1] - sy, a[2]), b])
        else:
            chunks[-1].append(b)
    return chunks


def tube_polygon(path, inset=0):
    left, right = [], []
    for i, (x, y, radius) in enumerate(path):
        a, b = path[max(0, i - 1)], path[min(len(path) - 1, i + 1)]
        dx, dy = b[0] - a[0], b[1] - a[1]
        length = math.hypot(dx, dy)
        if length < .001:
            continue
        width = max(.3, radius - inset)
        nx, ny = -dy / length * width, dx / length * width
        left.append((round(x + nx), round(y + ny)))
        right.append((round(x - nx), round(y - ny)))
    return left + right[::-1]


def head_angle(previous, current, alpha):
    angles = {'RIGHT': 0, 'UP': 90, 'LEFT': 180, 'DOWN': 270}
    a, b = angles[previous], angles[current]
    difference = (b - a + 180) % 360 - 180
    t = max(0, min(1, alpha / .65))
    return (a + difference * t * t * (3 - 2 * t)) % 360
