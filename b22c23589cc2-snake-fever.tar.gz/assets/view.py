"""Rendering only. Grid state never depends on display coordinates."""
import math
import random
from collections import Counter
from pathlib import Path

import pygame
from motion import body_path, head_angle, snake_path, tube_polygon, wrapped_chunks

ROOT = Path(__file__).resolve().parent
CELL, BOARD = 32, 640
WIDTH, HEIGHT = 960, 760
BOARD_RECT = pygame.Rect(32, 88, BOARD, BOARD)
BG = (24, 33, 35)
INK = (238, 242, 236)
MUTED = (163, 178, 175)
GREEN = (103, 172, 128)
BOARD_EDGE = (98, 125, 113)
GOLD = (231, 199, 103)
RED = (231, 121, 124)
SNAKE_COLORS = ((49, 95, 71), GREEN, (153, 198, 141))
TILE_COLORS = ((39, 58, 56), (46, 67, 64))
CONTROL_BORDER = (87, 108, 104)
DIVIDER = (67, 89, 84)
METER_TRACK = (62, 80, 76)
FEVER_FILL = (55, 54, 39)
FEVER_HOVER = (68, 67, 47)
KEY_SHADOW = (13, 21, 21)
KEY_DISABLED = (48, 64, 62)
FEVER_BUTTON = pygame.Rect(708, 391, 220, 52)


class View:
    def __init__(self):
        self.canvas = pygame.Surface((WIDTH, HEIGHT))
        self.board = pygame.Surface((BOARD, BOARD))
        self.fever_glow = pygame.Surface((48, 48), pygame.SRCALPHA)
        pygame.draw.rect(self.fever_glow, (*GOLD, 45), (3, 3, 42, 42), 3)
        self.banner_image = None
        self.fonts = {}
        self.text_cache = {}
        self.skins = {}
        self.rotations = {}
        self.particles = []
        self.rings = []
        self.bursts = []
        self.trails = []
        self.last_trail = 0
        self.age = 0.0
        self.banner = 0.0
        self.ready_flash = 0.0
        self.shake = 0.0
        self.buttons = {}
        self.tooltip = None
        self.rng = random.Random(52)
        self.burst_frames = []
        for i in range(6):
            path = ROOT / 'assets/retro' / f'burst_{i}.png'
            if path.exists():
                self.burst_frames.append(pygame.image.load(str(path)).convert_alpha())
        for skin in ('retro',):
            directory = ROOT / 'assets' / skin
            if not (directory / 'head.png').exists():
                continue
            self.skins[skin] = {}
            for name in ('head', 'body', 'corner', 'tail', 'apple', 'spark'):
                source = pygame.image.load(str(directory / (name + '.png'))).convert_alpha()
                size = 16 if name == 'spark' else CELL
                self.skins[skin][name] = pygame.transform.scale(source, (size, size))
                for angle in (0, 90, 180, 270):
                    self.rotations[skin, name, angle] = pygame.transform.rotate(self.skins[skin][name], angle)
        if not self.skins:
            raise RuntimeError('No retro sprite assets found. Restore assets/retro.')
        self.bonus_apples = []
        for alpha in range(0, 256, 32):
            apple = self.skins['retro']['apple'].copy()
            apple.set_alpha(alpha)
            self.bonus_apples.append(apple)
        self.bonus_apples.append(self.skins['retro']['apple'])
        self.floor = pygame.Surface((BOARD, BOARD))
        tiles = []
        for name, target in zip(('tile_dark', 'tile_light'), TILE_COLORS):
            path = ROOT / 'assets/retro' / (name + '.png')
            tile = pygame.transform.scale(pygame.image.load(str(path)).convert(), (CELL, CELL)) if path.exists() else None
            if tile is not None:
                # Recolor each tile once, retaining the source texture's grain.
                base = Counter(tuple(tile.get_at((x, y)))[:3]
                               for x in range(CELL) for y in range(CELL)).most_common(1)[0][0]
                delta = tuple(a - b for a, b in zip(target, base))
                tile.fill(tuple(max(0, d) for d in delta), special_flags=pygame.BLEND_RGB_ADD)
                tile.fill(tuple(max(0, -d) for d in delta), special_flags=pygame.BLEND_RGB_SUB)
            tiles.append(tile)
        for y in range(20):
            for x in range(20):
                tile = (x + y) % 2
                if tiles[tile]:
                    self.floor.blit(tiles[tile], (x * CELL, y * CELL))
                else:
                    pygame.draw.rect(self.floor, TILE_COLORS[tile], (x * CELL, y * CELL, CELL, CELL))

    def font(self, size):
        if size not in self.fonts:
            path = ROOT / 'assets/fonts/PressStart2P-Regular.ttf'
            self.fonts[size] = pygame.font.Font(str(path) if path.exists() else None, size)
        return self.fonts[size]

    def text(self, text, pos, size=12, color=INK, center=False, surface=None):
        key = (str(text), size, color)
        if key not in self.text_cache:
            if len(self.text_cache) >= 512:
                self.text_cache.pop(next(iter(self.text_cache)))
            self.text_cache[key] = self.font(size).render(str(text), False, color)
        image = self.text_cache[key]
        rect = image.get_rect(center=pos) if center else image.get_rect(topleft=pos)
        (surface or self.canvas).blit(image, rect)
        return rect

    def button(self, name, text, rect, mouse, active=False, disabled=False):
        rect = pygame.Rect(rect)
        self.buttons[name] = rect
        hover = rect.collidepoint(mouse) and not disabled
        color = GOLD if active else GREEN if hover else CONTROL_BORDER
        pygame.draw.rect(self.canvas, color if active else BG, rect)
        pygame.draw.rect(self.canvas, color, rect, 2)
        self.text(text, rect.center, 11, BG if active else MUTED if disabled else INK, True)

    def fever_button(self, enabled, mouse, reduced):
        rect = FEVER_BUTTON
        if enabled:
            self.buttons['fever'] = rect
        border = GOLD if enabled else CONTROL_BORDER
        if enabled and self.ready_flash > 0 and not reduced:
            pulse = math.sin(math.pi * (1 - self.ready_flash / .8))
            border = tuple(round(a + (b - a) * pulse) for a, b in zip(GOLD, INK))
        hover = enabled and rect.collidepoint(mouse)
        pygame.draw.rect(self.canvas, FEVER_HOVER if hover else FEVER_FILL if enabled else BG, rect)
        pygame.draw.rect(self.canvas, border, rect, 2)
        key = pygame.Rect(rect.x + 28, rect.y + 9, 34, 30)
        pygame.draw.rect(self.canvas, KEY_SHADOW, key.move(0, 4))
        pygame.draw.rect(self.canvas, GOLD if enabled else KEY_DISABLED, key)
        pygame.draw.rect(self.canvas, border, key, 2)
        self.text('F', key.center, 16, BG if enabled else MUTED, True)
        self.text('FEVER', (rect.x + 80, rect.y + 18), 16, INK if enabled else MUTED)

    def event(self, name, position, reduced):
        point = ((position[0] + .5) * CELL, (position[1] + .5) * CELL)
        if name in ('eat', 'trim', 'die', 'win', 'fever'):
            color = RED if name in ('die', 'trim') else GOLD
            count = 12 if reduced else 30
            for _ in range(count):
                angle = self.rng.random() * math.tau
                speed = self.rng.uniform(40, 180)
                self.particles.append([*point, math.cos(angle) * speed, math.sin(angle) * speed, self.rng.uniform(.2, .55), color])
            self.rings.append([*point, 0.0, color])
            if name == 'eat':
                self.bursts.append([*point, 0.0])
            # Bound overlapping effects without changing movement or collision rules.
            del self.particles[:-192]
            del self.rings[:-8]
            del self.bursts[:-8]
        if name == 'fever':
            self.banner = 1.0
            self.ready_flash = 0.0
        if name == 'fever_ready':
            self.ready_flash = .8
        if name == 'die' and not reduced:
            self.shake = .16

    def update(self, dt):
        self.age += dt
        self.banner = max(0, self.banner - dt)
        self.ready_flash = max(0, self.ready_flash - dt)
        self.shake = max(0, self.shake - dt)
        for p in self.particles:
            p[0] += p[2] * dt
            p[1] += p[3] * dt
            p[4] -= dt
        self.particles = [p for p in self.particles if p[4] > 0]
        for ring in self.rings:
            ring[2] += dt
        self.rings = [r for r in self.rings if r[2] < .3]
        for burst in self.bursts:
            burst[2] += dt
        self.bursts = [b for b in self.bursts if b[2] < .36]
        self.trails = [t for t in self.trails if self.age - t[2] < .15]

    def wrapped_sprite(self, image, point, wrap=True):
        cx, cy = point[0] % BOARD, point[1] % BOARD
        xs, ys = [0], [0]
        if wrap and cx < image.get_width() / 2:
            xs.append(BOARD)
        elif wrap and cx > BOARD - image.get_width() / 2:
            xs.append(-BOARD)
        if wrap and cy < image.get_height() / 2:
            ys.append(BOARD)
        elif wrap and cy > BOARD - image.get_height() / 2:
            ys.append(-BOARD)
        for ox in xs:
            for oy in ys:
                rect = image.get_rect(center=(round(cx + ox), round(cy + oy)))
                self.board.blit(image, rect)

    def snake(self, game, skin, reduced):
        alpha = min(1, game.progress) if game.status in ('playing', 'paused') else 1
        points = body_path(game.body, game.previous, alpha, CELL)
        angle = head_angle(game.previous_direction, game.direction, alpha)
        crossing_edge = any(abs(a - b) > 1 for a, b in zip(game.previous[0], game.body[0]))
        wrapping = game.fever or crossing_edge
        path = snake_path(points, angle)
        for chunk in wrapped_chunks(path, BOARD) if wrapping else [path]:
            if len(chunk) < 2:
                continue
            for inset, color in zip((0, 1.5, 4.5), SNAKE_COLORS):
                polygon = tube_polygon(chunk, inset)
                if len(polygon) >= 3:
                    pygame.draw.polygon(self.board, color, polygon)
        angle = round(angle / 3) * 3 % 360
        if ('face', angle) not in self.rotations:
            face = pygame.Surface((40, 40), pygame.SRCALPHA)
            for y in (13, 23):
                pygame.draw.rect(face, INK, (21, y, 5, 5))
                pygame.draw.rect(face, BG, (24, y + 1, 2, 3))
            self.rotations['face', angle] = pygame.transform.rotate(face, angle)
            ghost = pygame.Surface((40, 40), pygame.SRCALPHA)
            pygame.draw.ellipse(ghost, SNAKE_COLORS[1], (10, 11, 22, 18))
            self.rotations['trail', angle] = pygame.transform.rotate(ghost, angle)
        if game.fever and not reduced:
            self.wrapped_sprite(self.fever_glow, points[0])
        self.wrapped_sprite(self.rotations['face', angle], points[0], wrap=wrapping)
        if game.fever and not reduced and game.status == 'playing' and self.age - self.last_trail >= .025:
            self.trails.append((points[0], angle, self.age, skin))
            del self.trails[:-6]
            self.last_trail = self.age

    def render(self, game, settings, best, mouse, panel=None, fps=0, compact=False):
        c = self.canvas
        self.buttons = {}
        skin = 'retro'
        reduced = settings['reduced_motion']
        if not compact:
            c.fill(BG)
            self.text('SNAKE', (32, 27), 28)
            self.text('FEVER', (202, 27), 28, GOLD)
            self.button('pause', 'RESUME' if game.status == 'paused' else 'PAUSE', (694, 26, 112, 40), mouse)
            self.button('settings', 'SETTINGS', (818, 26, 112, 40), mouse)
        self.board.blit(self.floor, (0, 0))
        if game.food:
            x, y = game.food
            self.board.blit(self.skins[skin]['apple'], (x * CELL, y * CELL))
            if int(self.age * 2) % 3 == 0:
                self.board.blit(self.skins[skin]['spark'], (x * CELL + 20, y * CELL - 4))
        bonus_alpha = 8 if game.fever else max(1, min(8, math.ceil(game.bonus_left / .8 * 8)))
        for x, y in game.bonus_food:
            self.board.blit(self.bonus_apples[bonus_alpha], (x * CELL, y * CELL))
        if game.fever and not reduced:
            for point, angle, age, trail_skin in self.trails:
                ghost = self.rotations['trail', angle]
                ghost.set_alpha(round(95 * max(0, 1 - (self.age - age) / .15)))
                self.wrapped_sprite(ghost, point)
        for x, y, age in self.bursts:
            if self.burst_frames:
                frame = self.burst_frames[min(len(self.burst_frames) - 1, int(age / .36 * len(self.burst_frames)))]
                self.board.blit(frame, frame.get_rect(center=(round(x), round(y))))
        for x, y, age, color in self.rings:
            pygame.draw.circle(self.board, color, (round(x), round(y)), max(1, round(8 + age * 120)), max(1, round(3 - age * 6)))
        for p in self.particles:
            if p[4] > .3:
                self.board.blit(self.skins[skin]['spark'], (p[0] - 8, p[1] - 8))
            else:
                pygame.draw.rect(self.board, p[5], (p[0], p[1], 3, 3))
        # The head and path remain readable even during an overlapping burst.
        self.snake(game, skin, reduced)
        if compact:
            return self.board
        offset = (self.rng.randint(-2, 2), self.rng.randint(-2, 2)) if self.shake and not reduced else (0, 0)
        c.blit(self.board, BOARD_RECT.move(offset))
        pygame.draw.rect(c, GOLD if game.fever else BOARD_EDGE, BOARD_RECT.inflate(8, 8), 2)
        sx = 708
        self.text('SCORE', (sx, 94), 12, MUTED)
        self.text(f'{game.score:04d}', (sx, 123), 30, INK)
        self.text('PERSONAL BEST', (sx, 185), 10, MUTED)
        self.text(f'{best:04d}', (sx, 210), 20, MUTED)
        pygame.draw.line(c, DIVIDER, (sx, 259), (928, 259))
        available = game.status == 'playing' and game.fever_ready and panel is None
        fever_accent = GOLD if available or game.fever else MUTED
        self.text('FEVER', (sx, 287), 17, fever_accent)
        if game.fever:
            status = f'{"END " if game.fever_left <= 2 else ""}{game.fever_left:04.1f}s'
        elif not game.fever_ready:
            status = f'WAIT {game.fever_cooldown:04.1f}s'
        else:
            status = 'READY' if available else 'PAUSED' if game.status == 'paused' else 'STANDBY'
        self.text(status, (sx, 322), 16, fever_accent)
        pygame.draw.rect(c, METER_TRACK, (sx, 358, 220, 10))
        amount = game.fever_meter
        pygame.draw.rect(c, fever_accent, (sx, 358, round(220 * amount), 10))
        self.fever_button(available, mouse, reduced)
        pygame.draw.line(c, DIVIDER, (sx, 491), (928, 491))
        for label, value, y in [('BOARD', f'{len(game.body)} / 400', 519),
                                ('SPEED', f'{game.speed:04.1f}', 563)]:
            self.text(label, (sx, y + 2), 11, MUTED)
            self.text(value, (928 - self.font(14).size(value)[0], y), 14, MUTED)
        if settings.get('show_fps', False):
            self.text(f'{fps:03.0f} FPS', (32, HEIGHT - 19), 9, MUTED)
        if self.banner > 0 and game.status == 'playing':
            self.fever_banner(reduced)
        if panel == 'settings':
            self.settings_panel(settings, mouse)
        elif game.status in ('ready', 'paused', 'over', 'won'):
            shade = pygame.Surface((BOARD, BOARD), pygame.SRCALPHA)
            shade.fill((12, 17, 19, 210))
            c.blit(shade, BOARD_RECT)
            title = {'ready': 'READY?', 'paused': 'PAUSED', 'over': 'GAME OVER', 'won': 'BOARD CLEAR!'}[game.status]
            title_size = 28 if len(title) < 11 else 22
            title_height = self.font(title_size).get_height()
            has_score = game.status in ('over', 'won')
            score_height = self.font(16).get_height() if has_score else 0
            # Center the content that is actually present, without an empty score slot.
            group_height = title_height + 28 + 52 + (24 + score_height if has_score else 0)
            if game.status == 'paused':
                group_height += 16 + 42
            y = BOARD_RECT.centery - group_height // 2
            self.text(title, (BOARD_RECT.centerx, y + title_height // 2), title_size, GOLD if game.status == 'won' else INK, True)
            y += title_height
            if has_score:
                y += 24
                self.text(f'SCORE {game.score:04d}', (BOARD_RECT.centerx, y + score_height // 2), 16, INK, True)
                y += score_height
            y += 28
            self.button('start', 'PLAY' if game.status == 'ready' else 'RESUME' if game.status == 'paused' else 'PLAY AGAIN', (232, y, 240, 52), mouse, True)
            if game.status == 'paused':
                self.button('restart', 'RESTART', (232, y + 68, 240, 42), mouse)
        hints = {'pause': 'Pause / resume (Esc)', 'settings': 'Settings', 'restart': 'Restart round', 'start': 'Enter / Space'}
        for key, rect in self.buttons.items():
            if key in hints and rect.collidepoint(mouse):
                text = hints[key]
                self.text(text, (708, HEIGHT - 26), 8, MUTED)
        return c

    def fever_banner(self, reduced):
        if self.banner_image is None:
            self.banner_image = self.font(16).render('FEVER TIME!', False, GOLD)
        self.banner_image.set_alpha(255 if reduced else round(255 * min(1, self.banner / .25)))
        self.canvas.blit(self.banner_image, self.banner_image.get_rect(center=(510, 46)))

    def settings_panel(self, settings, mouse):
        shade = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        shade.fill((7, 10, 12, 225))
        self.canvas.blit(shade, (0, 0))
        self.buttons = {}
        self.text('SETTINGS', (480, 168), 25, INK, True)
        for i, (name, label) in enumerate([('music', 'MUSIC'), ('effects', 'SOUND FX')]):
            y = 245 + i * 86
            self.text(label, (260, y), 12, MUTED)
            rect = pygame.Rect(260, y + 30, 440, 20)
            self.buttons[name] = rect.inflate(0, 20)
            pygame.draw.rect(self.canvas, METER_TRACK, (rect.x, rect.y + 7, rect.w, 6))
            pygame.draw.rect(self.canvas, GREEN, (rect.x, rect.y + 7, round(rect.w * settings[name]), 6))
            pygame.draw.rect(self.canvas, INK, (rect.x + round(rect.w * settings[name]) - 5, rect.y, 10, 20))
        for name, label, y in [('reduced_motion', 'REDUCED MOTION', 444), ('assist', 'APPLE TURN ASSIST', 504), ('show_fps', 'SHOW FPS', 564)]:
            self.buttons[name] = pygame.Rect(260, y, 440, 32)
            pygame.draw.rect(self.canvas, GREEN if settings[name] else MUTED, (260, y, 24, 24), 2)
            if settings[name]:
                pygame.draw.rect(self.canvas, GREEN, (266, y + 6, 12, 12))
            self.text(label, (307, y + 5), 12)
        self.button('close_settings', 'DONE', (370, 638, 220, 46), mouse, True)
