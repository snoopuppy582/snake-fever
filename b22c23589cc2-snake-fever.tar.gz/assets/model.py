"""Deterministic grid rules, independent of pygame and rendering."""
from collections import deque
import random

SIZE = 20
FEVER_DURATION = 10.0
FEVER_COOLDOWN = 20.0
FEVER_FOOD_LIMIT = 8
BONUS_FOOD_GRACE = 2.0
DIRECTIONS = {'UP': (0, -1), 'DOWN': (0, 1), 'LEFT': (-1, 0), 'RIGHT': (1, 0)}
OPPOSITE = {'UP': 'DOWN', 'DOWN': 'UP', 'LEFT': 'RIGHT', 'RIGHT': 'LEFT'}


class Game:
    def __init__(self, seed=None):
        self.rng = random.Random(seed)
        self.reset()

    def reset(self):
        self.body = [(8, 10), (7, 10), (6, 10), (5, 10)]
        self.previous = self.body.copy()
        self.direction = 'RIGHT'
        self.previous_direction = self.direction
        self.queue = deque(maxlen=2)
        self.turn_target = None
        self.score = 0
        self.apples = 0
        self.status = 'ready'
        self.fever_left = 0.0
        self.fever_used = False
        self.fever_cooldown = 0.0
        self.hitstop = 0.0
        self.progress = 0.0
        self.events = []
        self.bonus_food = []
        self.bonus_left = 0.0
        self.food = self.spawn_food(initial=True)

    @property
    def fever(self):
        return self.fever_left > 0

    @property
    def fever_ready(self):
        return not self.fever and self.fever_cooldown <= 0

    @property
    def fever_meter(self):
        return self.fever_left / FEVER_DURATION if self.fever else 1 - self.fever_cooldown / FEVER_COOLDOWN

    @property
    def speed(self):
        normal = min(14.0, 8.5 + max(0, self.apples - 8) * 0.08)
        return normal + (24 - normal) * min(1, self.fever_left / 2) if self.fever else normal

    def spawn_food(self, initial=False, excluded=()):
        occupied = set(self.body) | set(self.bonus_food) | set(excluded)
        empty = [(x, y) for y in range(SIZE) for x in range(SIZE) if (x, y) not in occupied]
        if not empty:
            return None
        if initial:
            hx, hy = self.body[0]
            dx, dy = DIRECTIONS[self.direction]
            opening = [(x, y) for x, y in empty
                       if min(x, y, SIZE - 1 - x, SIZE - 1 - y) >= 3
                       and 3 <= abs(x - hx) + abs(y - hy) <= 7
                       and (x - hx) * dx + (y - hy) * dy >= 2]
            if opening:
                return self.rng.choice(opening)
        # Prefer room to approach and leave, but keep every empty cell possible.
        weights = []
        for x, y in empty:
            exits = sum(0 <= x + dx < SIZE and 0 <= y + dy < SIZE
                        and (x + dx, y + dy) not in occupied
                        for dx, dy in DIRECTIONS.values())
            edge_distance = min(x, y, SIZE - 1 - x, SIZE - 1 - y)
            edge_weight = (0.35, 0.6, 0.8, 1.0)[min(edge_distance, 3)]
            weights.append((0.25, 0.5, 2, 4, 4)[exits] * edge_weight)
        return self.rng.choices(empty, weights=weights, k=1)[0]

    def refill_bonus_food(self):
        if not self.fever:
            return
        while len(self.bonus_food) + (self.food is not None) < FEVER_FOOD_LIMIT:
            occupied = set(self.body) | set(self.bonus_food) | {self.food}
            needed = FEVER_FOOD_LIMIT - len(self.bonus_food) - (self.food is not None)
            if needed >= 3:
                x, y = self.body[0]
                dx, dy = DIRECTIONS[self.direction]
                approach = [((x + dx * i) % SIZE, (y + dy * i) % SIZE) for i in range(1, 5)]
                line = approach[1:] if all(p not in occupied for p in approach) else None
                if line is None:
                    lines = []
                    for y in range(SIZE):
                        for x in range(SIZE):
                            for dx, dy in ((1, 0), (0, 1)):
                                run = [(x + dx * i, y + dy * i) for i in range(3)]
                                if all(px < SIZE and py < SIZE and (px, py) not in occupied for px, py in run):
                                    lines.append(run)
                    if lines:
                        line = self.rng.choice(lines)
                if line:
                    self.bonus_food.extend(line)
                    continue
            position = self.spawn_food(excluded=(self.food,))
            if position is None:
                break
            self.bonus_food.append(position)

    def turn(self, direction, assist=False):
        if direction not in DIRECTIONS or self.status not in ('ready', 'playing'):
            return
        if self.turn_target and direction == self.turn_target[2]:
            return
        previous = self.queue[-1] if self.queue else self.direction
        if direction not in (previous, OPPOSITE[previous]) and len(self.queue) < 2:
            self.turn_target = None
            if (assist and not self.queue and self.food and not self.fever
                    and (1 - self.progress) / self.speed <= 0.06):
                dx, dy = DIRECTIONS[self.direction]
                tx, ty = DIRECTIONS[direction]
                x, y = self.body[0]
                fx, fy = self.food
                if dx and fx == x + dx and ty * (fy - y) > 0:
                    self.turn_target = (0, fx, direction)
                elif dy and fy == y + dy and tx * (fx - x) > 0:
                    self.turn_target = (1, fy, direction)
                if self.turn_target:
                    # Never delay an escape into a blocked approach or apple lane.
                    approach = (x + dx, y + dy)
                    lane = [approach]
                    px, py = approach
                    while (px, py) != self.food:
                        px, py = px + tx, py + ty
                        lane.append((px, py))
                    if any(p in self.body or not (0 <= p[0] < SIZE and 0 <= p[1] < SIZE)
                           for p in lane):
                        self.turn_target = None
                if self.turn_target:
                    self.status = 'playing'
                    return
            self.queue.append(direction)
        if self.status == 'ready':
            self.status = 'playing'

    def clear_input(self):
        self.queue.clear()
        self.turn_target = None

    def activate_fever(self):
        if self.status != 'playing' or not self.fever_ready:
            return False
        self.fever_used = True
        self.fever_left = FEVER_DURATION
        self.bonus_left = 0.0
        self.refill_bonus_food()
        self.hitstop = 0.15
        self.events.append(('fever', self.body[0]))
        return True

    def update(self, dt):
        if self.status != 'playing':
            return
        # Small slices keep timer boundaries and movement consistent across frame rates.
        remaining = max(0.0, dt)
        while remaining > 1e-9 and self.status == 'playing':
            step_time = min(remaining, 1 / 240)
            if self.hitstop <= 0:
                boundary = self.fever_left or self.fever_cooldown
                if boundary > 0:
                    step_time = min(step_time, boundary)
            remaining -= step_time
            if self.hitstop > 0:
                blocked = min(step_time, self.hitstop)
                self.hitstop -= blocked
                step_time -= blocked
            if step_time <= 0:
                continue
            was_fever = self.fever
            self.progress += step_time * self.speed
            while self.progress >= 1 and self.status == 'playing':
                self.progress -= 1
                self.step()
            if self.status != 'playing':
                break
            if self.fever_left > 0:
                old = self.fever_left
                self.fever_left = max(0, self.fever_left - step_time)
                if self.fever_left < 1e-9:
                    self.fever_left = 0
                if old > 2 >= self.fever_left:
                    self.events.append(('warning', self.body[0]))
                if self.fever_left == 0:
                    self.fever_cooldown = FEVER_COOLDOWN
                    self.bonus_left = BONUS_FOOD_GRACE
                    self.events.append(('fever_end', self.body[0]))
            elif self.fever_cooldown > 0:
                self.fever_cooldown = max(0, self.fever_cooldown - step_time)
                if self.fever_cooldown < 1e-9:
                    self.fever_cooldown = 0
                    self.events.append(('fever_ready', self.body[0]))
            if not was_fever and self.bonus_left > 0:
                self.bonus_left = max(0.0, self.bonus_left - step_time)
                if self.bonus_left < 1e-9:
                    self.bonus_left = 0.0
                    self.bonus_food.clear()

    def step(self):
        self.previous_direction = self.direction
        if self.turn_target and self.body[0][self.turn_target[0]] == self.turn_target[1]:
            self.direction = self.turn_target[2]
            self.turn_target = None
        elif self.queue:
            self.direction = self.queue.popleft()
        dx, dy = DIRECTIONS[self.direction]
        x, y = self.body[0]
        next_pos = (x + dx, y + dy)
        if self.fever:
            next_pos = (next_pos[0] % SIZE, next_pos[1] % SIZE)
        elif not (0 <= next_pos[0] < SIZE and 0 <= next_pos[1] < SIZE):
            self.die()
            return
        eating = next_pos == self.food or next_pos in self.bonus_food
        occupied = self.body if eating else self.body[:-1]
        self.previous = self.body.copy()
        if next_pos in occupied:
            if not self.fever:
                self.die()
                return
            index = self.body.index(next_pos)
            self.body = self.body[:index]
            self.events.append(('trim', next_pos))
        elif not eating:
            self.body.pop()
        self.body.insert(0, next_pos)
        if self.direction != self.previous_direction:
            self.events.append(('turn', next_pos))
        if eating:
            self.apples += 1
            self.score += 2 if self.fever else 1
            self.events.append(('eat', next_pos))
            if next_pos == self.food:
                self.food = None
            if next_pos in self.bonus_food:
                self.bonus_food.remove(next_pos)
            if len(self.body) == SIZE * SIZE:
                self.food = None
                self.bonus_food.clear()
                self.status = 'won'
                self.events.append(('win', next_pos))
            else:
                if self.food is None:
                    self.food = self.spawn_food()
                    if self.food is None and self.bonus_food:
                        self.food = self.bonus_food.pop(0)
                self.refill_bonus_food()

    def die(self):
        self.status = 'over'
        self.progress = 1.0
        self.events.append(('die', self.body[0]))

    def drain_events(self):
        events, self.events = self.events, []
        return events
