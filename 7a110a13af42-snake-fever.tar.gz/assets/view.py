"""Rendering only. Grid state never depends on display coordinates."""
import math
import random
from pathlib import Path

import pygame
from motion import body_path, head_angle, snake_path, tube_polygon, wrapped_chunks

ROOT = Path(__file__).resolve().parent
CELL, BOARD = 32, 640
WIDTH, HEIGHT = 960, 800
BOARD_RECT = pygame.Rect(32, 112, BOARD, BOARD)
BG = (20, 23, 26)
INK = (238, 243, 239)
MUTED = (145, 155, 153)
GREEN = (110, 235, 151)
GOLD = (255, 213, 91)
RED = (255, 110, 114)
SNAKE_COLORS = ((23, 90, 62), (96, 222, 151), (164, 245, 174))


class View:
    def __init__(self):
        self.canvas = pygame.Surface((WIDTH, HEIGHT))
        self.board = pygame.Surface((BOARD, BOARD))
        self.fonts = {}
        self.text_cache = {}
        self.skins = {}
        self.rotations = {}
        self.particles = []
        self.rings = []
        self.bursts = []
        self.trails = []
        self.last_trail = 0
        self.age = 0.0
        self.banner = 0.0
        self.shake = 0.0
        self.buttons = {}
        self.tooltip = None
        self.rng = random.Random(52)
        self.burst_frames = []
        for i in range(6):
            path = ROOT / 'assets/retro' / f'burst_{i}.png'
            if path.exists():
                self.burst_frames.append(pygame.image.load(str(path)).convert_alpha())
        for skin in ('retro',):
            directory = ROOT / 'assets' / skin
            if not (directory / 'head.png').exists():
                continue
            self.skins[skin] = {}
            for name in ('head', 'body', 'corner', 'tail', 'apple', 'spark'):
                source = pygame.image.load(str(directory / (name + '.png'))).convert_alpha()
                size = 16 if name == 'spark' else CELL
                self.skins[skin][name] = pygame.transform.scale(source, (size, size))
                for angle in (0, 90, 180, 270):
                    self.rotations[skin, name, angle] = pygame.transform.rotate(self.skins[skin][name], angle)
        if not self.skins:
            raise RuntimeError('No retro sprite assets found. Restore assets/retro.')
        self.floor = pygame.Surface((BOARD, BOARD))
        tiles = []
        for name in ('tile_dark', 'tile_light'):
            path = ROOT / 'assets/retro' / (name + '.png')
            tiles.append(pygame.transform.scale(pygame.image.load(str(path)).convert(), (CELL, CELL)) if path.exists() else None)
        for y in range(20):
            for x in range(20):
                tile = (x + y) % 2
                if tiles[tile]:
                    self.floor.blit(tiles[tile], (x * CELL, y * CELL))
                else:
                    pygame.draw.rect(self.floor, [(46, 50, 52), (54, 58, 60)][tile], (x * CELL, y * CELL, CELL, CELL))

    def font(self, size):
        if size not in self.fonts:
            path = ROOT / 'assets/fonts/PressStart2P-Regular.ttf'
            self.fonts[size] = pygame.font.Font(str(path) if path.exists() else None, size)
        return self.fonts[size]

    def text(self, text, pos, size=12, color=INK, center=False, surface=None):
        key = (str(text), size, color)
        if key not in self.text_cache:
            if len(self.text_cache) >= 512:
                self.text_cache.pop(next(iter(self.text_cache)))
            self.text_cache[key] = self.font(size).render(str(text), False, color)
        image = self.text_cache[key]
        rect = image.get_rect(center=pos) if center else image.get_rect(topleft=pos)
        (surface or self.canvas).blit(image, rect)
        return rect

    def button(self, name, text, rect, mouse, active=False, disabled=False):
        rect = pygame.Rect(rect)
        self.buttons[name] = rect
        hover = rect.collidepoint(mouse) and not disabled
        color = GOLD if active else GREEN if hover else (68, 79, 77)
        pygame.draw.rect(self.canvas, color if active else BG, rect)
        pygame.draw.rect(self.canvas, color, rect, 2)
        self.text(text, rect.center, 11, BG if active else MUTED if disabled else INK, True)

    def event(self, name, position, reduced):
        point = ((position[0] + .5) * CELL, (position[1] + .5) * CELL)
        if name in ('eat', 'trim', 'die', 'win', 'fever'):
            color = RED if name in ('die', 'trim') else GOLD
            count = 12 if reduced else 30
            for _ in range(count):
                angle = self.rng.random() * math.tau
                speed = self.rng.uniform(40, 180)
                self.particles.append([*point, math.cos(angle) * speed, math.sin(angle) * speed, self.rng.uniform(.2, .55), color])
            self.rings.append([*point, 0.0, color])
            if name == 'eat':
                self.bursts.append([*point, 0.0])
        if name == 'fever':
            self.banner = 1.0
        if name in ('fever', 'die') and not reduced:
            self.shake = .16

    def update(self, dt):
        self.age += dt
        self.banner = max(0, self.banner - dt)
        self.shake = max(0, self.shake - dt)
        for p in self.particles:
            p[0] += p[2] * dt
            p[1] += p[3] * dt
            p[4] -= dt
        self.particles = [p for p in self.particles if p[4] > 0]
        for ring in self.rings:
            ring[2] += dt
        self.rings = [r for r in self.rings if r[2] < .3]
        for burst in self.bursts:
            burst[2] += dt
        self.bursts = [b for b in self.bursts if b[2] < .36]
        self.trails = [t for t in self.trails if self.age - t[2] < .15]

    def wrapped_sprite(self, image, point, wrap=True):
        cx, cy = point[0] % BOARD, point[1] % BOARD
        xs, ys = [0], [0]
        if wrap and cx < image.get_width() / 2:
            xs.append(BOARD)
        elif wrap and cx > BOARD - image.get_width() / 2:
            xs.append(-BOARD)
        if wrap and cy < image.get_height() / 2:
            ys.append(BOARD)
        elif wrap and cy > BOARD - image.get_height() / 2:
            ys.append(-BOARD)
        for ox in xs:
            for oy in ys:
                rect = image.get_rect(center=(round(cx + ox), round(cy + oy)))
                self.board.blit(image, rect)

    def snake(self, game, skin, reduced):
        alpha = min(1, game.progress) if game.status in ('playing', 'paused') else 1
        points = body_path(game.body, game.previous, alpha, CELL)
        angle = head_angle(game.previous_direction, game.direction, alpha)
        crossing_edge = any(abs(a - b) > 1 for a, b in zip(game.previous[0], game.body[0]))
        wrapping = game.fever or crossing_edge
        path = snake_path(points, angle)
        for chunk in wrapped_chunks(path, BOARD) if wrapping else [path]:
            if len(chunk) < 2:
                continue
            for inset, color in zip((0, 1.5, 4.5), SNAKE_COLORS):
                polygon = tube_polygon(chunk, inset)
                if len(polygon) >= 3:
                    pygame.draw.polygon(self.board, color, polygon)
        angle = round(angle / 3) * 3 % 360
        if ('face', angle) not in self.rotations:
            face = pygame.Surface((40, 40), pygame.SRCALPHA)
            for y in (13, 23):
                pygame.draw.rect(face, INK, (21, y, 5, 5))
                pygame.draw.rect(face, BG, (24, y + 1, 2, 3))
            self.rotations['face', angle] = pygame.transform.rotate(face, angle)
            ghost = pygame.Surface((40, 40), pygame.SRCALPHA)
            pygame.draw.ellipse(ghost, SNAKE_COLORS[1], (10, 11, 22, 18))
            self.rotations['trail', angle] = pygame.transform.rotate(ghost, angle)
        if game.fever and not reduced:
            glow = pygame.Surface((48, 48), pygame.SRCALPHA)
            pygame.draw.rect(glow, (*GOLD, 45), (3, 3, 42, 42), 3)
            self.wrapped_sprite(glow, points[0])
        self.wrapped_sprite(self.rotations['face', angle], points[0], wrap=wrapping)
        if game.fever and not reduced and game.status == 'playing' and self.age - self.last_trail >= .025:
            self.trails.append((points[0], angle, self.age, skin))
            self.last_trail = self.age

    def render(self, game, settings, best, mouse, panel=None, fps=0, compact=False):
        c = self.canvas
        c.fill(BG)
        self.buttons = {}
        skin = 'retro'
        reduced = settings['reduced_motion']
        accent = GOLD if game.fever else GREEN
        self.text('SNAKE', (32, 27), 28)
        self.text('FEVER', (202, 27), 28, GOLD)
        self.text('01 / ARCADE', (33, 76), 10, MUTED)
        self.button('pause', 'RESUME' if game.status == 'paused' else 'PAUSE', (694, 26, 112, 40), mouse)
        self.button('settings', 'SETTINGS', (818, 26, 112, 40), mouse)
        self.board.blit(self.floor, (0, 0))
        if game.food:
            x, y = game.food
            self.board.blit(self.skins[skin]['apple'], (x * CELL, y * CELL))
            if int(self.age * 2) % 3 == 0:
                self.board.blit(self.skins[skin]['spark'], (x * CELL + 20, y * CELL - 4))
        if game.fever and not reduced:
            for point, angle, age, trail_skin in self.trails:
                ghost = self.rotations['trail', angle].copy()
                ghost.set_alpha(round(95 * max(0, 1 - (self.age - age) / .15)))
                self.wrapped_sprite(ghost, point)
        self.snake(game, skin, reduced)
        for x, y, age in self.bursts:
            if self.burst_frames:
                frame = self.burst_frames[min(len(self.burst_frames) - 1, int(age / .36 * len(self.burst_frames)))]
                self.board.blit(frame, frame.get_rect(center=(round(x), round(y))))
        for x, y, age, color in self.rings:
            pygame.draw.circle(self.board, color, (round(x), round(y)), max(1, round(8 + age * 120)), max(1, round(3 - age * 6)))
        for p in self.particles:
            if p[4] > .3:
                self.board.blit(self.skins[skin]['spark'], (p[0] - 8, p[1] - 8))
            else:
                pygame.draw.rect(self.board, p[5], (p[0], p[1], 3, 3))
        offset = (self.rng.randint(-2, 2), self.rng.randint(-2, 2)) if self.shake and not reduced else (0, 0)
        c.blit(self.board, BOARD_RECT.move(offset))
        pygame.draw.rect(c, accent, BOARD_RECT.inflate(8, 8), 2)
        if compact:
            if self.banner > 0 and game.status == 'playing':
                self.fever_banner(reduced)
            return c.subsurface(BOARD_RECT)
        sx = 708
        self.text('SCORE', (sx, 118), 12, MUTED)
        self.text(f'{game.score:04d}', (sx, 147), 30, INK)
        self.text('PERSONAL BEST', (sx, 209), 10, MUTED)
        self.text(f'{best:04d}', (sx, 234), 20, GOLD)
        pygame.draw.line(c, (62, 69, 69), (sx, 283), (928, 283))
        self.text('FEVER', (sx, 311), 17, accent)
        status = f'{game.fever_left:04.1f}s' if game.fever else f'WAIT {game.fever_cooldown:04.1f}s' if not game.fever_ready else 'READY'
        self.text(status, (sx, 346), 16, accent if game.fever_ready or game.fever else MUTED)
        pygame.draw.rect(c, (58, 63, 64), (sx, 382, 220, 10))
        amount = game.fever_meter
        pygame.draw.rect(c, accent, (sx, 382, round(220 * amount), 10))
        self.button('fever', 'FEVER', (sx, 415, 220, 45), mouse, game.fever, not game.fever_ready)
        if game.fever and game.fever_left <= 2:
            self.text('ENDING', (sx, 478), 12, GOLD)
        self.text('BOARD', (sx, 517), 11, MUTED)
        self.text(f'{len(game.body)} / 400', (sx, 545), 14)
        self.text('SPEED', (sx, 595), 11, MUTED)
        self.text(f'{game.speed:04.1f}', (sx, 621), 18, accent)
        self.text('RETRO', (sx, 720), 10, MUTED)
        self.text(f'{fps:03.0f} FPS', (32, 775), 9, MUTED)
        self.text('20 x 20', (604, 775), 9, MUTED)
        if self.banner > 0 and game.status == 'playing':
            self.fever_banner(reduced)
        if panel == 'settings':
            self.settings_panel(settings, mouse)
        elif game.status in ('ready', 'paused', 'over', 'won'):
            shade = pygame.Surface((BOARD, BOARD), pygame.SRCALPHA)
            shade.fill((12, 17, 19, 210))
            c.blit(shade, BOARD_RECT)
            title = {'ready': 'READY?', 'paused': 'PAUSED', 'over': 'GAME OVER', 'won': 'BOARD CLEAR!'}[game.status]
            self.text(title, (352, 350), 28 if len(title) < 11 else 22, GOLD if game.status == 'won' else INK, True)
            if game.status in ('over', 'won'):
                self.text(f'SCORE {game.score:04d}', (352, 404), 16, accent, True)
            self.button('start', 'PLAY' if game.status == 'ready' else 'RESUME' if game.status == 'paused' else 'PLAY AGAIN', (232, 456, 240, 52), mouse, True)
            if game.status == 'paused':
                self.button('restart', 'RESTART', (232, 527, 240, 42), mouse)
        hints = {'pause': 'Pause / resume (Esc)', 'settings': 'Settings', 'fever': 'Fever time (F)', 'restart': 'Restart round', 'start': 'Enter / Space'}
        for key, rect in self.buttons.items():
            if key in hints and rect.collidepoint(mouse):
                text = hints[key]
                self.text(text, (708, 766), 8, MUTED)
        return c

    def fever_banner(self, reduced):
        progress = 1 - self.banner
        size = 36 if reduced else round(32 + 8 * max(0, 1 - progress * 5))
        image = self.font(size).render('FEVER TIME!', False, GOLD)
        if self.banner < .25:
            image.set_alpha(round(255 * self.banner / .25))
        backing = pygame.Surface((BOARD, 100), pygame.SRCALPHA)
        backing.fill((15, 19, 22, 220))
        self.canvas.blit(backing, (32, 380))
        self.canvas.blit(image, image.get_rect(center=(352, 430)))

    def settings_panel(self, settings, mouse):
        shade = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        shade.fill((7, 10, 12, 225))
        self.canvas.blit(shade, (0, 0))
        self.buttons = {}
        self.text('SETTINGS', (480, 168), 25, INK, True)
        for i, (name, label) in enumerate([('music', 'MUSIC'), ('effects', 'SOUND FX')]):
            y = 245 + i * 86
            self.text(label, (260, y), 12, MUTED)
            rect = pygame.Rect(260, y + 30, 440, 20)
            self.buttons[name] = rect.inflate(0, 20)
            pygame.draw.rect(self.canvas, (58, 66, 65), (rect.x, rect.y + 7, rect.w, 6))
            pygame.draw.rect(self.canvas, GREEN, (rect.x, rect.y + 7, round(rect.w * settings[name]), 6))
            pygame.draw.rect(self.canvas, INK, (rect.x + round(rect.w * settings[name]) - 5, rect.y, 10, 20))
        for name, label, y in [('reduced_motion', 'REDUCED MOTION', 444), ('assist', 'APPLE TURN ASSIST', 504)]:
            self.buttons[name] = pygame.Rect(260, y, 440, 32)
            pygame.draw.rect(self.canvas, GREEN if settings[name] else MUTED, (260, y, 24, 24), 2)
            if settings[name]:
                pygame.draw.rect(self.canvas, GREEN, (266, y + 6, 12, 12))
            self.text(label, (307, y + 5), 12)
        self.button('close_settings', 'DONE', (370, 590, 220, 46), mouse, True)
