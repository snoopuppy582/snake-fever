# /// script
# dependencies = ["pygame-ce"]
# ///
"""Browser entry point; desktop gameplay and rendering stay unchanged."""
import asyncio
import json
import time
import traceback

import pygame
import platform

from desktop_app import App, DEFAULTS
from view import BOARD, WIDTH, HEIGHT

STORAGE_KEY = 'snake-fever.save.v1'


class WebApp(App):
    def __init__(self):
        self.mobile = bool(platform.window.sfTouch)
        self.resume_left = 0.0
        self.ui_last = 0.0
        super().__init__(size=(BOARD, BOARD) if self.mobile else (WIDTH, HEIGHT))

    def load(self):
        try:
            data = json.loads(platform.window.localStorage.getItem(STORAGE_KEY) or '{}')
            self.best = max(0, int(data.get('best', 0)))
            saved = data.get('settings', {})
            for key in ('music', 'effects'):
                self.settings[key] = max(0, min(1, float(saved.get(key, DEFAULTS[key]))))
            for key in ('reduced_motion', 'assist'):
                self.settings[key] = bool(saved.get(key, DEFAULTS[key]))
            if 'reduced_motion' not in saved:
                self.settings['reduced_motion'] = bool(platform.window.matchMedia('(prefers-reduced-motion: reduce)').matches)
        except Exception:
            # Storage may be disabled in private browsing or by site permissions.
            pass

    def save(self):
        try:
            platform.window.localStorage.setItem(
                STORAGE_KEY, json.dumps({'best': self.best, 'settings': self.settings}))
        except Exception:
            pass

    def handle(self, event):
        # F11 belongs to the browser, not SDL's desktop fullscreen mode.
        if event.type == pygame.KEYDOWN and event.key == pygame.K_F11:
            return
        if self.mobile and event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
            return
        super().handle(event)

    def pause(self):
        if self.game.status == 'paused' and not self.resume_left:
            self.resume_left = .65
        else:
            self.resume_left = 0
            if self.game.status == 'playing':
                super().pause()

    def restart(self):
        self.resume_left = 0
        super().restart()

    def settings_open(self):
        self.resume_left = 0
        super().settings_open()

    def settings_close(self):
        super().settings_close()
        if self.game.status == 'playing':
            self.game.status = 'paused'
            self.audio.pause(True)
            self.resume_left = .65

    def browser_input(self):
        mobile = bool(platform.window.sfTouch)
        interrupted = bool(platform.window.sfInterrupted)
        if mobile != self.mobile or interrupted:
            if self.game.status == 'playing':
                self.pause()
            self.resume_left = 0
            self.game.queue.clear()
            self.game.turn_target = None
            platform.window.sfClear()
            platform.window.sfInterrupted = False
            self.save()
        if mobile != self.mobile:
            if self.panel:
                self.settings_close()
                self.resume_left = 0
            self.mobile = mobile
            self.window = pygame.display.set_mode((BOARD, BOARD) if mobile else (WIDTH, HEIGHT), pygame.RESIZABLE)
        for command in json.loads(platform.window.sfDrain()):
            action = command.get('action')
            value = command.get('value')
            if action == 'setting' and self.panel and isinstance(value, dict):
                key = value.get('name')
                if key in ('music', 'effects'):
                    self.settings[key] = max(0, min(1, float(value['value'])))
                    self.audio.set_volumes(self.settings['music'], self.settings['effects'])
                elif key in ('assist', 'reduced_motion'):
                    self.settings[key] = bool(value['value'])
                self.save()
            elif action == 'close_settings' and self.panel:
                self.action(action)
            elif not self.panel:
                if action == 'turn' and not self.resume_left:
                    self.game.turn(value, self.settings['assist'])
                elif action in ('start', 'restart', 'pause', 'settings', 'fever'):
                    self.action(action)

    def draw(self):
        if self.mobile:
            frame = self.view.render(self.game, self.settings, self.best, (-100, -100), fps=self.fps, compact=True)
            self.window.blit(pygame.transform.scale(frame, self.window.get_size()), (0, 0))
            pygame.display.flip()
        else:
            super().draw()
        now = time.perf_counter()
        if now - self.ui_last >= .05:
            self.ui_last = now
            platform.window.sfRender(json.dumps({
                'score': self.game.score, 'best': self.best, 'status': self.game.status,
                'fever': self.game.fever, 'left': self.game.fever_left,
                'cooldown': self.game.fever_cooldown, 'ready': self.game.fever_ready,
                'meter': self.game.fever_meter, 'panel': self.panel,
                'settings': self.settings, 'countdown': self.resume_left,
            }))

    async def run_web(self):
        last = time.perf_counter()
        saved_best = self.best
        was_hidden = False
        platform.window.snakeFeverReady = True
        while self.running:
            now = time.perf_counter()
            dt, last = now - last, now
            hidden = bool(platform.window.document.hidden)
            self.browser_input()
            for event in pygame.event.get():
                self.handle(event)
            if not self.running:
                break
            if hidden and not was_hidden:
                if self.game.status == 'playing':
                    self.pause()
                self.audio.pause(True)
                self.resume_left = 0
                self.save()
            elif was_hidden and not hidden:
                self.audio.pause(self.game.status == 'paused' or bool(self.panel))
            was_hidden = hidden
            if dt > .25 and self.game.status == 'playing':
                self.pause()
            if not hidden:
                if self.resume_left > 0:
                    self.resume_left = max(0, self.resume_left - min(dt, .25))
                    if self.resume_left == 0:
                        self.game.status = 'playing'
                        self.audio.pause(False)
                self.update(min(dt, .25))
                if self.best != saved_best:
                    self.save()
                    saved_best = self.best
                self.draw()
                self.clock.tick()
                self.fps = self.clock.get_fps()
            # Yield to browser input, audio, rendering, and requestAnimationFrame.
            await asyncio.sleep(0)
        self.save()
        pygame.quit()


async def main():
    try:
        app = WebApp()
        await app.run_web()
    except Exception:
        platform.window.sfFatal = traceback.format_exc()
        platform.window.console.error(platform.window.sfFatal)
        platform.window.infobox.innerText = 'GAME ERROR - PLEASE RELOAD'
        platform.window.infobox.style.display = 'grid'
        raise


asyncio.run(main())
