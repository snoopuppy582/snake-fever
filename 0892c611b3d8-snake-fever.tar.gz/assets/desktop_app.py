import argparse
import json
import os
from pathlib import Path
import sys
import time

os.environ.setdefault('PYGAME_HIDE_SUPPORT_PROMPT', '1')
import pygame

from audio import Audio
from model import Game
from view import View, WIDTH, HEIGHT

ROOT = Path(__file__).resolve().parent
DEFAULTS = {'music': .35, 'effects': .65, 'reduced_motion': False, 'assist': False}
KEYS = {pygame.K_UP: 'UP', pygame.K_w: 'UP', pygame.K_DOWN: 'DOWN', pygame.K_s: 'DOWN',
        pygame.K_LEFT: 'LEFT', pygame.K_a: 'LEFT', pygame.K_RIGHT: 'RIGHT', pygame.K_d: 'RIGHT'}


def default_save_path():
    if getattr(sys, 'frozen', False):
        local = Path(os.environ.get('LOCALAPPDATA', Path.home() / 'AppData/Local'))
        return local / 'SnakeFever/save.json'
    return ROOT / 'save.json'


class App:
    def __init__(self, size=(WIDTH, HEIGHT), save_path=None, seed=None):
        pygame.mixer.pre_init(44100, -16, 2, 512)
        pygame.init()
        self.window = pygame.display.set_mode(size, pygame.RESIZABLE)
        pygame.display.set_caption('Snake Fever')
        self.clock = pygame.time.Clock()
        self.view = View()
        pygame.display.set_icon(self.view.skins[next(iter(self.view.skins))]['head'])
        self.game = Game(seed)
        self.save_path = Path(save_path) if save_path else default_save_path()
        self.settings = DEFAULTS.copy()
        self.best = 0
        self.load()
        self.audio = Audio(self.settings['music'], self.settings['effects'])
        self.audio.music()
        self.running = True
        self.panel = None
        self.return_state = 'ready'
        self.fullscreen = False
        self.windowed_size = size
        self.dragging = None
        self.viewport = pygame.Rect(0, 0, *size)
        self.fps = 0

    def load(self):
        try:
            data = json.loads(self.save_path.read_text(encoding='utf-8'))
            self.best = max(0, int(data.get('best', 0)))
            saved = data.get('settings', {})
            for key in ('music', 'effects'):
                self.settings[key] = max(0, min(1, float(saved.get(key, DEFAULTS[key]))))
            for key in ('reduced_motion', 'assist'):
                self.settings[key] = bool(saved.get(key, DEFAULTS[key]))
        except (OSError, ValueError, TypeError, AttributeError):
            pass

    def save(self):
        try:
            self.save_path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self.save_path.with_suffix('.tmp')
            temporary.write_text(json.dumps({'best': self.best, 'settings': self.settings}, indent=2), encoding='utf-8')
            temporary.replace(self.save_path)
        except OSError:
            pass

    def pause(self):
        if self.game.status in ('playing', 'paused'):
            self.game.clear_input()
            self.game.status = 'paused' if self.game.status == 'playing' else 'playing'
            self.audio.pause(self.game.status == 'paused')

    def restart(self):
        self.game.reset()
        self.game.status = 'playing'
        self.view.particles.clear()
        self.view.rings.clear()
        self.view.bursts.clear()
        self.view.trails.clear()
        self.view.banner = 0
        self.view.ready_flash = 0
        self.view.shake = 0
        self.audio.pause(False)
        self.audio.music(False)

    def settings_open(self):
        self.game.clear_input()
        self.return_state = self.game.status
        if self.game.status == 'playing':
            self.game.status = 'paused'
        self.panel = 'settings'
        self.audio.pause(True)

    def settings_close(self):
        self.game.status = self.return_state
        self.panel = None
        self.dragging = None
        self.audio.pause(self.game.status == 'paused')
        self.save()

    def logical_mouse(self, pos):
        if not self.viewport.w or not self.viewport.h:
            return (-100, -100)
        return ((pos[0] - self.viewport.x) * WIDTH / self.viewport.w,
                (pos[1] - self.viewport.y) * HEIGHT / self.viewport.h)

    def action(self, name):
        self.audio.play('click')
        if name == 'settings':
            self.settings_open()
        elif name == 'close_settings':
            self.settings_close()
        elif name == 'pause':
            self.pause()
        elif name == 'start':
            if self.game.status == 'ready':
                self.game.status = 'playing'
            elif self.game.status == 'paused':
                self.pause()
            else:
                self.restart()
        elif name == 'restart':
            self.restart()
        elif name == 'fever':
            self.game.activate_fever()
        elif name in ('assist', 'reduced_motion'):
            self.settings[name] = not self.settings[name]

    def handle(self, event):
        if event.type == pygame.QUIT:
            self.running = False
        elif event.type == pygame.WINDOWFOCUSLOST:
            if self.game.status == 'playing':
                self.pause()
        elif event.type == pygame.KEYDOWN:
            key = event.key
            if key == pygame.K_F11:
                self.fullscreen = not self.fullscreen
                if self.fullscreen:
                    self.windowed_size = self.window.get_size()
                self.window = pygame.display.set_mode((0, 0) if self.fullscreen else self.windowed_size,
                                                      pygame.FULLSCREEN if self.fullscreen else pygame.RESIZABLE)
            elif key == pygame.K_ESCAPE:
                if self.panel:
                    self.settings_close()
                else:
                    self.pause()
            elif not self.panel:
                if key in KEYS and not getattr(event, 'repeat', False):
                    self.game.turn(KEYS[key], self.settings['assist'])
                elif key == pygame.K_f and not getattr(event, 'repeat', False):
                    self.game.activate_fever()
                elif key in (pygame.K_SPACE, pygame.K_RETURN):
                    if self.game.status != 'playing':
                        self.action('start')
                elif key == pygame.K_r and self.game.status in ('over', 'won', 'paused'):
                    self.restart()
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            point = self.logical_mouse(event.pos)
            for name, rect in self.view.buttons.items():
                if rect.collidepoint(point):
                    if name in ('music', 'effects'):
                        self.dragging = name
                        self.slider(point)
                    else:
                        self.action(name)
                    break
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            self.slider(self.logical_mouse(event.pos))
        elif event.type == pygame.MOUSEBUTTONUP:
            self.dragging = None

    def slider(self, point):
        self.settings[self.dragging] = max(0, min(1, (point[0] - 260) / 440))
        self.audio.set_volumes(self.settings['music'], self.settings['effects'])

    def update(self, dt):
        self.game.update(dt)
        if self.game.score > self.best:
            self.best = self.game.score
        for name, position in self.game.drain_events():
            self.view.event(name, position, self.settings['reduced_motion'])
            self.audio.play(name)
            if name in ('fever', 'fever_end'):
                self.audio.music(name == 'fever')
            if name in ('die', 'win'):
                self.audio.pause(False)
                if self.audio.available:
                    pygame.mixer.music.fadeout(450)
                self.audio.mode = None
                self.save()
        if self.game.status != 'paused':
            self.view.update(dt)

    def draw(self):
        w, h = self.window.get_size()
        scale = min(w / WIDTH, h / HEIGHT)
        target = (max(1, round(WIDTH * scale)), max(1, round(HEIGHT * scale)))
        self.viewport = pygame.Rect((w - target[0]) // 2, (h - target[1]) // 2, *target)
        image = self.view.render(self.game, self.settings, self.best,
                                 self.logical_mouse(pygame.mouse.get_pos()), self.panel, self.fps)
        self.window.fill((10, 12, 13))
        self.window.blit(pygame.transform.scale(image, target) if target != (WIDTH, HEIGHT) else image, self.viewport)
        pygame.display.flip()

    def run(self, seconds=None):
        start = last = time.perf_counter()
        while self.running:
            now = time.perf_counter()
            dt = now - last
            last = now
            for event in pygame.event.get():
                self.handle(event)
            if not self.running:
                break
            # Long OS stalls pause instead of silently consuming a fever or killing the player.
            if dt > .25 and self.game.status == 'playing':
                self.pause()
            self.update(min(dt, .25))
            self.draw()
            # SDL's integer-millisecond limiter rounds 144 Hz to ~166 Hz on some systems.
            deadline = now + 1 / 144
            remaining = deadline - time.perf_counter()
            if remaining > .001:
                time.sleep(remaining - .001)
            while time.perf_counter() < deadline:
                pass
            self.clock.tick()
            self.fps = self.clock.get_fps()
            if seconds is not None and now - start >= seconds:
                self.running = False
        self.save()
        pygame.quit()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--smoke-seconds', type=float)
    args = parser.parse_args()
    try:
        App().run(args.smoke_seconds)
    finally:
        pygame.quit()
