from array import array
import math
from pathlib import Path

import pygame

ROOT = Path(__file__).resolve().parent / 'assets/audio'


class Audio:
    def __init__(self, music=0.35, effects=0.65):
        self.available = pygame.mixer.get_init() is not None
        self.music_volume, self.effects_volume = music, effects
        self.mode = None
        self.sounds = {}
        self.eat_index = 0
        if not self.available:
            return
        self.sounds['eat'] = pygame.mixer.Sound(str(ROOT / 'eat.ogg'))
        pygame.mixer.set_reserved(4)
        self.turn_channel = pygame.mixer.Channel(0)
        self.eat_channel = pygame.mixer.Channel(1)
        self.chime_channel = pygame.mixer.Channel(2)
        self.cue_channel = pygame.mixer.Channel(3)
        self.sounds['turn'] = self.tone([(440, .04)], gain=.4, harmonic=.06)
        for name, notes in {
            'fever': [(330, .07), (440, .07), (660, .08), (880, .18)],
            'warning': [(880, .08), (0, .08), (660, .1)],
            'fever_end': [(660, .07), (440, .07), (330, .15)],
            'fever_ready': [(660, .06), (880, .09)],
            'die': [(220, .1), (165, .12), (110, .25)],
            'trim': [(130, .045), (260, .06)],
            'win': [(440, .1), (550, .1), (660, .1), (880, .35)],
            'click': [(660, .04)],
            'eat_chime': [(660, .035), (990, .07)],
            'eat_chime_alt': [(740, .035), (1110, .07)],
        }.items():
            self.sounds[name] = self.tone(notes)
        self.set_volumes(music, effects)

    def tone(self, notes, gain=1.0, harmonic=.22):
        rate = pygame.mixer.get_init()[0]
        samples = array('h')
        for frequency, duration in notes:
            count = int(rate * duration)
            for i in range(count):
                envelope = min(1, i / (rate * .005), (count - i) / (rate * .02))
                phase = 2 * math.pi * frequency * i / rate
                value = int(6500 * gain * envelope * (math.sin(phase) + harmonic * math.sin(3 * phase))) if frequency else 0
                samples.extend((value, value))
        return pygame.mixer.Sound(buffer=samples.tobytes())

    def set_volumes(self, music, effects):
        self.music_volume, self.effects_volume = music, effects
        if self.available:
            pygame.mixer.music.set_volume(music)
            for name, sound in self.sounds.items():
                weight = .65 if name.startswith('eat_chime') else .75 if name in ('eat', 'fever_ready') else 1
                sound.set_volume(effects * weight)

    def play(self, name):
        if self.available and name in self.sounds:
            if name == 'turn':
                self.turn_channel.play(self.sounds[name])
            elif name == 'eat':
                self.eat_channel.play(self.sounds[name])
            elif name in ('fever', 'warning', 'fever_end', 'fever_ready', 'die', 'win'):
                self.cue_channel.play(self.sounds[name])
            else:
                self.sounds[name].play()
            if name == 'eat':
                chime = 'eat_chime_alt' if self.eat_index % 2 else 'eat_chime'
                self.chime_channel.play(self.sounds[chime])
                self.eat_index += 1

    def music(self, fever=False):
        mode = 'fever' if fever else 'normal'
        if not self.available or mode == self.mode:
            return
        self.mode = mode
        pygame.mixer.music.load(str(ROOT / ('fever.ogg' if fever else 'normal.ogg')))
        pygame.mixer.music.play(-1, fade_ms=180)

    def pause(self, value):
        if self.available:
            if value:
                pygame.mixer.music.pause()
                pygame.mixer.pause()
            else:
                pygame.mixer.music.unpause()
                pygame.mixer.unpause()
